import { useGames } from '../context/gameContext';
import { Link } from 'react-router-dom';
import '../assets/styles/main.css';
const GameList = () => {
  const { games } = useGames();

  return (
    <div className="game-list">
      {games.map((game) => (
        <Link to={`/game/${game.id}`} key={game.id} className="game-card">
          <img 
            src={game.images[0]} 
            alt={game.title}
            onError={(e) => {
              e.target.src = game.images[1];
            }}
            className="game-image"
          />
          <div className="game-info">
            <h3>{game.title}</h3>
            <p className="game-price">
              {game.price === 0 ? 'Free to Play' : `$${game.price.toFixed(2)}`}
            </p>
            <p className="game-category">{game.category}</p>
          </div>
        </Link>
      ))}
    </div>
  );
};

export default GameList;